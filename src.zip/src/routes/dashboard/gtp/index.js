/**
 * Ecommerce Dashboard once created structure in asyncomponent folder need to import here 
 */

import React, { Component } from 'react';


//Reloadable card
import {GtpWidget,
		OperationWidget,
		BinRetrivalTimeWidget,
		SortersWidget} from "Components/Widgets";

// intl messages
import IntlMessages from 'Util/IntlMessages';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';


export default class Gtp extends Component {
   render() {
      const { match } = this.props;
      return (
         <div className="ecom-dashboard-wrapper">
            <PageTitleBar title={<IntlMessages id="sidebar.GTPDashboard" />} match={match} />
            <div className="row row-no-margin">
            	<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 col-class-left">
					<GtpWidget/>
					<div className="clearboth"></div>
					<BinRetrivalTimeWidget/>
            	</div>
				
            	<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 col-class-right">
            		<OperationWidget/>
            	</div>
            </div>
         </div>
      )
   }
}
