import React, { Component } from 'react';

//import './landing.css';
import ArcProgressbar from './arc/SegmentedArcProgressBar/ArcProgressbar';
import 'react-circular-progressbar/dist/styles.css';

// Import custom examples
import SegmentedArcProgressbar from './arc/SegmentedArcProgressbar';

class OverallWorkMonitor extends Component {
    render(){
	const percentage = 35;
      return(
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="componentbg overall-work-monitor row-no-margin">
                       <div className="title"><b>Overall Work Monitor</b></div>
					   <div className="col-sm-5 col-md-5 col-lg-5 col-xl-5 leftAlign">
							<div className="subtitle"><b>Productivity</b></div>
								<div style={{paddingLeft: '15px'}}>
								<div style={{ width: '120px', height: '120px' , paddingLeft: '5px'}}>
								  <SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
								</div>
								</div>
								<div className="titleBar">Total Average</div>
								<div className="station-status-activetext"><i>Per Hour</i></div>
					   </div>
					   <div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
					   <div className="subtitle"><b>Station status</b></div>
						   <div>
							   <div className="station-status-textblack"><b>99</b></div> 
							   <div className="station-status-activetext">Total</div>
						   </div>
					   <div>
							   <div className="station-status-textblack"><b>88</b></div> 
							   <div className="station-status-activetext">Active</div>
						   </div>
					   <div>
							   <div className="station-status-textblack"><b>77</b></div> 
							   <div className="station-status-activetext">Inactive</div>
						   </div>
					   </div>
					   <div className="col-sm-3 col-md-3 col-lg-3 col-xl-3 leftAlign">
					   <div className="subtitle"><b>Bin Status</b></div>
					   <div>
							   <div className="station-status-textblack">9999</div> 
							   <div className="station-status-activetext">Processed</div>
						   </div>
					   <div>
							   <div className="station-status-textblack">999<span className="station-status-subLabel"><i>/Hr</i></span></div> 
							   <div className="station-status-activetext">Process Rate</div>
						   </div>
					   </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                      
      );
    }
  }
export default OverallWorkMonitor;
